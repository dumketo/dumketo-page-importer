jQuery(document).ready(function($){		
	var app = {
		init: function(){
			app.upload_script();
			app.start_import();
		},
		upload_script: function(){
			$('#dumketo-page-csv').die('click').live('change', function(){
				$("#imageform").ajaxForm({target: '#csv_upload_result', 				    
				    beforeSubmit:function(){ 
						$("#drag-drop-area").addClass('upload-ongoing');
					 	$("#csvloadbutton").hide();
					},					
					success:function(){
					 	$("#drag-drop-area").removeClass('upload-ongoing');
					 	$("#plupload-upload-ui").slideToggle('slow');
					 	$('#dumketo-start-import').show();
					 	app.start_draggable();
					},
					error:function(){ 
						$("#drag-drop-area").removeClass('upload-ongoing');
					 	$("#imageloadstatus").hide();
						$("#csvloadbutton").show();
						$('#dumketo-start-import').hide();
					}
				}).submit();				

			});
		},
		start_import: function(){
			$('body').on('click', '#dumketo-start-import', function(){
				if( !$(this).hasClass('import-complete') ){
					if( $('#csv-column-name').val() ){
						var that = $(this);
						that.val('Working...');
						jQuery.ajax({
							type: 'POST',
							url: '/wp-content/plugins/dumketo-page-importer/form-submit.php',
							data: {
								'csv_file': that.attr('data-file'),
								'records': $('#csv_upload_result .updated p strong').text(),
								'name_alias': $('#csv-column-name').val(),
								'title_alias': $('#csv-column-title').val(),
								'description_alias': $('#csv-column-description').val(),
								'action':'dumketo_csv_import'
							},
							success: function(msg) {
								$('#csv_upload_result .updated p').html('All done! <strong>' + $('#csv_upload_result .updated p strong').text() + '</strong> entries has been imported! (<a href="#" id="see-results-link">See results</a>)');
								$('.csv-tree-wrap').slideToggle('slow');
								that.val('Done');
								that.addClass('import-complete');
								var obj = $.parseJSON( msg );
								logs_html = '';
								$.each( obj.logs, function(i, data) {
									logs_html += '<a href="' + data.permalink + '">' + data.permalink + '</a> (Success)<br />';
								});	
								$('.csv-tree-wrap').before('<div class="import-results">' + logs_html + '</div>');
								app.after_import();
							}
						});
					}else{
						alert( 'Post/Page Name is required. Please try again.' );
					}
				}else{
					location.reload();
				}
				return false;
			});
		},
		after_import: function(){
			$('body').on('click', 'a#see-results-link', function(){
				$('div.import-results').slideToggle('slow');
			});
		},
		start_draggable: function(){
			$( ".automatic_page_genarator .draggable" ).draggable( { revert: true } );
		    $( ".automatic_page_genarator .droppable" ).droppable({
		      	drop: function( event, ui ) { console.log( $(ui.draggable).text() ); $( this ).addClass( "ui-state-highlight" ).val( $(ui.draggable).text() ); } });
		}
	};
	app.init();
});