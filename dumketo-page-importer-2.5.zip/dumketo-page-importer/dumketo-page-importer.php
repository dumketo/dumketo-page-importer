<?php
/*
Plugin Name: Dumketo Page Importer
Plugin URI: http://dumketo.github.io/Resume/
Version: 2.5
Author: Hasan Ahmed Jobayer
Description: Dumketo page Importer Developed By Hasan Ahmed Jobayer
*/

class DumketopageImporter {
	private $capability = 'manage_options';

	public function __construct() {
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'add_plugin_actions_links' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menu_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'dumketo_page_importer_enqueue_files' ) );
		add_action( 'dumketo_page_importer_csv_import', array(&$this, 'dumketo_page_importer_csv_import'));
	}
	function dumketo_page_importer_enqueue_files($hook){
		wp_register_style( 'dumketo_page_importer_wp_admin', plugin_dir_url( __FILE__ ) . 'css/dumketo-page-importer-style.css' );
	    wp_enqueue_style( 'dumketo_page_importer_wp_admin' );
	    wp_register_script( 'dumketo_page_importer_wp_admin_wallform_js', plugin_dir_url( __FILE__ ) . 'js/jquery.dumketo-page-importer-csvUploader.js' );
	    wp_enqueue_script( 'dumketo_page_importer_wp_admin_wallform_js' );
	    wp_enqueue_script( 'jquery-ui-draggable' );
	    wp_enqueue_script( 'jquery-ui-droppable' );
		wp_register_script( 'dumketo_page_importer_wp_admin_js', plugin_dir_url( __FILE__ ) . 'js/dumketo-page-importer-js.js' );
	    wp_enqueue_script( 'dumketo_page_importer_wp_admin_js' );
	    
	}
	public function add_admin_menu_page() {
		add_options_page(
			__( 'Dumketo page Importer', 'automatic-page-genarator' ),
			__( 'Dumketo page Importer', 'automatic-page-genarator' ),
			$this->capability,
			'dumketo-page-importer',
			array( $this, 'automatic_page_genarator' )
		);
	}
	public function automatic_page_genarator() {
		$message = ''; ?>		
		<div class="wrap automatic_page_genarator">
			<h2>Dumketo page Importer</h2>
			<?php echo $message; ?>
			<form id="imageform" method="POST" enctype="multipart/form-data" action="<?php echo plugin_dir_url(__FILE__); ?>upload.php">
				<div id="plupload-upload-ui" class="hide-if-no-js drag-drop" style="margin-top: 20px;">
					<div id="drag-drop-area" style="position: relative;">
						<div class="drag-drop-inside" style="margin-top: 85px;">
							<p class="drag-drop-buttons" id="csvloadbutton">
								<input type="file" name="dumketo-page-csv" id="dumketo-page-csv" accept=".csv" style="position: relative; z-index: 1;" />
								<?php $upload_dir = wp_upload_dir(); ?>
								<input type="hidden" name="upload_dir" value="<?php echo $upload_dir['basedir']; ?>">
							</p>
						</div>
					</div>
				</div>
			</form>
			<div id='csv_upload_result'></div>
		</div>
	<?php }
	
	public function add_plugin_actions_links( $links ) {
		$mylinks = array( '<a href="' . admin_url( 'options-general.php?page=dumketo-page-importer' ) . '">Settings</a>', );
		return array_merge( $links, $mylinks );
	}
}
new DumketopageImporter;

require_once (plugin_dir_path( __FILE__ ) . '/lib/update/plugin-update-checker.php' );
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker('https://github.com/dumketo/dumketo-page-importer/raw/master/plugin.json', __FILE__, 'dumketo-page-importer'); 