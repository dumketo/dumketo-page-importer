<?php 
require_once('lib/dumketo.parsecsv.lib.php');
require_once("../../../wp-load.php");
function remove_brackets($str){
    $str = str_replace('{', '', $str);
    $str = str_replace('}', '', $str);
    return $str;
}
global $wpdb;
if( $_POST['csv_file'] and $_POST['action'] and $_POST['action'] == 'dumketo_csv_import' ){
	$csv = new DumketoparseCSV( $_POST['csv_file'] );
	$count = 0;
    $name_alias = remove_brackets( $_POST['name_alias'] );
    $title_alias = remove_brackets( $_POST['title_alias'] );
    $description_alias = remove_brackets( $_POST['description_alias'] );
    $log_arr = array();		    
    if( $_POST['name_alias'] ){		        
        foreach($csv->data as $item) {
            $count++;
            $page_name = $item[ $name_alias ];
            $have_page = get_page_by_title( $page_name );
			if ( $have_page->post_title == $page_name  ){
                update_post_meta( $have_page->ID, '_yoast_wpseo_title', $item[$title_alias]);		                    
                update_post_meta( $have_page->ID, '_yoast_wpseo_metadesc', $item[$description_alias]);
                $log_entry = array( 'id' => $have_page->ID, 'title' => get_the_title( $have_page->ID ), 'permalink' => get_permalink( $have_page->ID ) );
			}else{
				$page = array(
				    'post_title'  =>  $page_name,
				    'post_status' =>  'publish',
				    'post_type'   =>  'page',
				    'post_author' =>   1,
			    );
			    $create_page =  wp_insert_post( $page );
                add_post_meta( $create_page, '_yoast_wpseo_title', $item[$title_alias]);
                add_post_meta( $create_page, '_yoast_wpseo_metadesc', $item[$description_alias]);		
                $log_entry = array( 'id' => $create_page, 'title' => get_the_title( $create_page ), 'permalink' => get_permalink( $create_page ) );	    
			}
            array_push( $log_arr, $log_entry );
        }
	}
}
$import_status = ( $_POST['records'] == $count ) ? 'Success' : 'Failed';	    
echo json_encode( array( 'import_status' => $import_status, 'logs' => $log_arr ) );